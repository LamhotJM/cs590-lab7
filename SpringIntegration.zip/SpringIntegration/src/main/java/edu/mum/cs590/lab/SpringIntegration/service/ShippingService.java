package edu.mum.cs590.lab.SpringIntegration.service;

import edu.mum.cs590.lab.SpringIntegration.model.Order;

public class ShippingService {

    public void processOrder(Order order){
        System.out.println("Order no: " + order.getOrderNo() + " has been received for shipping");
    }
}
