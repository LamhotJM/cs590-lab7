package edu.mum.cs590.lab.SpringIntegration.model;
public class Greeting {
    private String content;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}