package edu.mum.cs590.lab.SpringIntegration.service;

import org.springframework.stereotype.Service;

import edu.mum.cs590.lab.SpringIntegration.model.Order;

public class WareHouseService {

    public void processOrder(Order order){
        System.out.println("Order number: " + order.getOrderNo() + " has been received into the warehouse");
    }
}
