package edu.mum.cs590.lab.SpringIntegration.integration;

import org.springframework.integration.annotation.Gateway;
import org.springframework.integration.annotation.MessagingGateway;
import org.springframework.messaging.Message;

import edu.mum.cs590.lab.SpringIntegration.model.Order;

@MessagingGateway
public interface OrderGateway {
    @Gateway(requestChannel = "inputChannel")
    void handleRequest(Order order);
}
