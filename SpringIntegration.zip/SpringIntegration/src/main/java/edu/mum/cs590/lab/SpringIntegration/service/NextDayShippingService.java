package edu.mum.cs590.lab.SpringIntegration.service;

public class NextDayShippingService extends ShippingService {
    
}
